// import logo from './logo.svg';
import './App.css';
import Table from './components/Table';

function App() {
  return (

<>
<Table/>
</>
  );
}

export default App;
