import React, { useState } from "react";
// import Data from './Data.json'
import "../components/Prac.css";


const Table = () => {
  // const [data,setData]=useState();

  const [addformdata, setaddformdata] = useState({
    fullname: "",
    address: "",
    phoneno: "",
    email: "",
  });

  const [newdata, setnewdata] = useState([]);

  const handleInput = (e) => {
    e.preventDefault();

    let value = e.target.value;
    let name = e.target.name;

    setaddformdata({ ...addformdata, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    setnewdata([...newdata, addformdata]);
    setaddformdata({
      fullname: "",
      address: "",
      phoneno: "",
      email: "",
    });
    console.log(addformdata);
  };

  const deldata = (id) => {
    const update = newdata.filter((current_value, index) => {
      return index !== id;
    });
    setnewdata(update);
  };

  return (
    <>
      <div className="container">
        
        <div className="Details">
          <h1>Details</h1>
          <form className="form-group " onSubmit={handleSubmit}>
            <input
              type="text"
              placeholder="enter name"
              required="required"
              className="form-control w-50 d-inline"
              name="fullname"
              value={addformdata.fullname}
              onChange={handleInput}
            ></input>
            <input
              type="text"
              placeholder="enter address"
              required="required"
              className="form-control w-50 ms-1 mt-2"
              name="address"
              value={addformdata.address}
              onChange={handleInput}
            ></input>
            <input
              type="number"
              placeholder="enter number"
              required="required"
              className="form-control w-50 mt-2  ms-1"
              name="phoneno"
              value={addformdata.phoneno}
              onChange={handleInput}
            ></input>
            <input
              type="email"
              placeholder="enter email"
              required="required"
              className="form-control w-50 d-inline ms-1 mt-2"
              name="email"
              value={addformdata.email}
              onChange={handleInput}
            ></input>
            <button className="btn btn-success w-50 mt-2 ms-1" type="submit ">
              Submit
            </button>
          </form>
        </div>
        

        <div className="data">
          <table className="table table-striped  table-hover mt-5">
            <thead>
              <tr>
                <th>Name</th>
                <th>Address</th>
                <th>Phone No:</th>
                <th>Emaill</th>
              </tr>
            </thead>
            <tbody>
              {/* {data.map((datas)=>(
                    <tr>
                    <td>{datas.fullname}</td>
                    <td>{datas.address}</td>
                    <td>{datas.phoneno}</td>
                    <td>{datas.email}</td>
    
                </tr>
                ))} */}

              {newdata.map((current_value, index) => {
                return (
                  <>
                    <tr key={index}>
                      <td>{current_value.fullname}</td>
                      <td>{current_value.address}</td>
                      <td>{current_value.phoneno}</td>
                      <td>{current_value.email}</td>
                    </tr>
                    <button
                      className="btn btn-danger d-inline mt-2"
                      onClick={() => {
                        deldata(index);
                      }}
                      type="submit"
                    >
                      Delete
                    </button>
                  </>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
      
    </>
  );
};

export default Table;
